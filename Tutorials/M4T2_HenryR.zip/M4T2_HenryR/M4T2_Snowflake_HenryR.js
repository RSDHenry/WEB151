penwidth(4)
pendown()
for (i = 0; i < 6; i++) {
// for loop will run the code to draw the all six branches
//  Code for a single snowflake branch
fd(100)
fd(-40)
lt(40)
fd(30)
fd(-30)
rt(80)
fd(30)
fd(-30)
lt(40)
fd(-60)
rt(60)
}